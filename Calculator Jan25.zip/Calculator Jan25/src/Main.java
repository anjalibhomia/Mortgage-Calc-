public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}

import java.text.NumberFormat;
        import java.util.Scanner;

public class MortgageCalculator {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        double loanAmount = 0;
        double interestRate = 0;
        int loanTerm = 0;

        while (loanAmount <= 0) {
            try {
                System.out.print("Enter loan amount: ");
                loanAmount = input.nextDouble();
                if (loanAmount <= 0) {
                    throw new IllegalArgumentException("Loan amount must be greater than 0.");
                }
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a valid number.");
                input.nextLine();
            }
        }

        while (interestRate <= 0) {
            try {
                System.out.print("Enter interest rate (e.g. 5 for 5%): ");
                interestRate = input.nextDouble();
                if (interestRate <= 0) {
                    throw new IllegalArgumentException("Interest rate must be greater than 0.");
                }
                interestRate /= 100;
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a valid number.");
                input.nextLine();
            }
        }

        while (loanTerm <= 0) {
            try {
                System.out.print("Enter loan term (in years): ");
                loanTerm = input.nextInt();
                if (loanTerm <= 0) {
                    throw new IllegalArgumentException("Loan term must be greater than 0.");
                }
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a valid number.");
                input.nextLine();
            }

